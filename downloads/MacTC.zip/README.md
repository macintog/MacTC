# MacTC Package

This folder contains the MacTC installer package for MacTC v1.0 (646).

## Install

**MacTC opens in System mode with MacTC fan control disabled.** It monitors
temperatures and performance without taking control of your fans. MacTC fan
control stays disabled until you choose MacTC mode.

**Monitoring is free forever.** The seven-day MacTC fan-control trial begins
the first time you click **MacTC**. After the seven-day trial, MacTC fan control
requires a one-time purchase.

1. Open the included `.pkg` file in Installer.
2. Finish the Installer flow.
3. Open `/Applications/MacTC.app` if it does not launch automatically.

The installer includes the EULA pane. MacTC shows its active-control consent once, immediately before starting a trial or purchase, or when a restored purchaser first enables MacTC mode.

## Installed contents

- App: `/Applications/MacTC.app`
- Support files:
  - `/Library/PrivilegedHelperTools/com.macintog.mactc.fanhelper`
  - `/Library/PrivilegedHelperTools/Frameworks/MacTCFanControlIPC.framework`
  - `/Library/LaunchDaemons/com.macintog.mactc.fanhelper.plist`
  - `/Library/Application Support/MacTC/`

## Uninstaller

MacTC includes its uninstaller at:

```bash
/Library/Application\ Support/MacTC/uninstall-mactc.sh
```

Use `--purge-data` to remove local MacTC application data too.
