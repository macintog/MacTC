# MacTC First Launch

## Title

Before You Use MacTC

## Body

MacTC is designed to change your Mac's fan behavior when active control is
available and approved. That usually means more fan activity and more fan
noise. Some beta builds or modes may evaluate control in preview or shadow
before live fan writes are enabled.

MacTC is intended to improve thermal control, but it cannot guarantee better
thermal outcomes in every circumstance. Hardware differences, firmware changes,
macOS changes, sensor faults, unusual workloads, ambient conditions, and other
unforeseen interactions may reduce its effectiveness or worsen thermal
behavior.

By clicking I Agree, you confirm that you understand these limitations and want
to continue using MacTC.

## Default Button

I Agree

## Cancel Button

Cancel
