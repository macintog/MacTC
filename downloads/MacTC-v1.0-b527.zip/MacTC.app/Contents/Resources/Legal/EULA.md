# MacTC End User License Agreement

Effective date: April 1, 2026

MacTC is offered by R&D Solutions LLC under the Macintog brand. This End User
License Agreement governs your installation and use of MacTC.

## 1. Thermal Control Software

MacTC modifies, influences, previews, or evaluates fan behavior and related
thermal-management behavior on supported Mac hardware. When active fan control
is available and enabled, its purpose is to pursue lower operating
temperatures, typically at the cost of more fan activity, more fan noise, and
potentially more power use. Some beta builds or modes may operate in preview or
shadow observation before live fan writes are enabled.

## 2. No Guarantee of Outcome

MacTC is intended to improve thermal control in many situations, but R&D
Solutions LLC does not represent or warrant that using MacTC will improve
temperatures, improve stability, improve hardware safety, improve component
longevity, prevent throttling, or produce any other specific result in every
circumstance.

Thermal behavior depends on many factors outside the developer's control,
including hardware differences, component aging, firmware behavior, macOS
behavior, background workloads, battery condition, charger state, external
displays, docked or clamshell use, ambient temperature, airflow, dust, sleep
and wake transitions, sensor errors, third-party software, and future operating
system or firmware changes.

In rare or unforeseen circumstances, MacTC may be less effective than intended
or may worsen thermal behavior.

## 3. Assumption of Risk

By installing, enabling, or using MacTC, and especially by enabling MacTC mode
or any other non-default control mode when active fan control is available, you
acknowledge that modifying fan behavior carries inherent risk and that not all hardware, firmware,
environmental, and workload interactions can be predicted, modeled, or
prevented.

## 4. No Warranty

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, MACTC IS PROVIDED "AS IS,"
"WITH ALL FAULTS," AND "AS AVAILABLE." R&D SOLUTIONS LLC DISCLAIMS ALL
WARRANTIES, WHETHER EXPRESS, IMPLIED, STATUTORY, OR OTHERWISE, INCLUDING ANY
IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
ACCURACY, QUIET ENJOYMENT, AND NON-INFRINGEMENT.

WITHOUT LIMITING THE FOREGOING, R&D SOLUTIONS LLC DOES NOT WARRANT THAT MACTC
WILL:

- achieve any particular thermal result;
- be compatible with all Mac hardware or software configurations;
- operate without interruption or error;
- prevent overheating, throttling, instability, component aging, battery
  degradation, or hardware damage; or
- remain effective after future operating system, firmware, or hardware changes.

No oral or written statement, documentation, support communication, marketing
statement, or other information provided by R&D Solutions LLC creates any
warranty unless expressly stated in a signed written agreement.

## 5. Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, R&D SOLUTIONS LLC SHALL NOT
BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, EXEMPLARY, OR
PUNITIVE DAMAGES, OR FOR ANY LOSS OF DATA, LOSS OF USE, LOSS OF PROFITS,
BUSINESS INTERRUPTION, COST OF REPAIR, COST OF REPLACEMENT EQUIPMENT,
DIMINUTION IN VALUE, OR OTHER COMMERCIAL OR PERSONAL LOSS ARISING OUT OF OR
RELATED TO MACTC OR ITS USE OR INABILITY TO BE USED, HOWEVER CAUSED AND UNDER
ANY THEORY OF LIABILITY.

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, R&D SOLUTIONS LLC'S TOTAL
AGGREGATE LIABILITY ARISING OUT OF OR RELATED TO MACTC SHALL NOT EXCEED THE
GREATER OF:

- the amount you paid for MacTC in the twelve months preceding the event giving
  rise to the claim; or
- US $50.

## 6. User Responsibility

You are responsible for using MacTC only on hardware and operating system
versions identified as supported. You are also responsible for following the
documentation, warnings, and recommended operating conditions, including
maintaining reasonable airflow and avoiding obviously unsafe environmental
conditions.

## 7. Indemnity for Misuse

You agree to indemnify, defend, and hold harmless R&D Solutions LLC from
third-party claims, liabilities, damages, judgments, losses, and reasonable
attorneys' fees arising from:

- your misuse of MacTC;
- your use of MacTC contrary to the documentation or warnings;
- your use of MacTC on unsupported hardware or unsupported system
  configurations after notice of incompatibility;
- your disabling or bypassing of safety-related features provided by MacTC; or
- your modification or redistribution of MacTC in violation of this Agreement.

This indemnity does not require you to indemnify R&D Solutions LLC for claims
to the extent caused by its own fraud, willful misconduct, or any liability
that cannot be shifted or limited under applicable law.

## 8. Consumer Rights Carveout

Some jurisdictions do not allow certain disclaimers, exclusions, indemnity
provisions, or limitations of liability. To the extent such laws apply to you,
some parts of this Agreement may not apply, and this Agreement will apply only
to the maximum extent permitted by applicable law.

## 9. Acknowledgment

By installing or using MacTC, you acknowledge that you have read and understood
this Agreement, including the sections titled No Guarantee of Outcome,
Assumption of Risk, No Warranty, and Limitation of Liability, and that you
agree to them.
