# Enable MacTC Mode

## Title

Turn On MacTC Mode?

## Body

MacTC mode lets the app evaluate earlier intervention than the system's default
fan behavior. When active fan control is available and approved, that can reduce
temperatures under load, but it can also increase fan noise, power use, and the
chance of unexpected behavior on some machines or future macOS releases. Some
beta builds may remain in preview or shadow observation until live control is
approved.

Only turn on MacTC mode if you understand that results vary and that no
fan-control policy can guarantee better thermal outcomes in every case.

## Primary Button

Agree and Enable

## Cancel Button

Cancel
